package hexad.retail.bakery.test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestCFProduct.class, TestMB11Product.class,TestVS5Product.class  })
public class TestSuite {

}
